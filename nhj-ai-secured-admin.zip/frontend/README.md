# NHJ AI — Frontend (v0.1)

React + Vite. Talks to the FastAPI backend in `../backend`.

## Run locally

```bash
cd frontend
npm install
npm run dev
```

Opens on http://localhost:5173. In dev, requests to `/api/*` are proxied
to `http://127.0.0.1:8000` (see `vite.config.js`) — start the backend
first (`uvicorn app.main:app --reload` from `../backend`).

Login with the seeded admin: `admin@nhj.local` / `ChangeMe123!`.

## Build for production

```bash
npm run build
```

Outputs static files to `dist/`.

**Important — same-origin vs. separate hosting:**
- If the built frontend is served from the *same domain* as the backend
  (e.g. FastAPI serves `dist/` as static files, or a reverse proxy puts
  both behind one host), no extra config is needed.
- If the frontend is deployed to a *different domain* than the API
  (e.g. frontend on Vercel/Netlify, backend elsewhere), you must:
  1. Set `VITE_API_BASE_URL` at build time to the full backend URL, e.g.
     `VITE_API_BASE_URL=https://api.example.com/api/v1 npm run build`
  2. Set `CORS_ORIGINS` on the backend to the frontend's exact origin
     (see `backend/app/core/config.py` / the `CORS_ORIGINS` env var).

  Skipping either step is the most common reason a deployed login button
  silently "does nothing": without the base URL, requests go to the
  frontend's own domain and 404; without CORS, the browser blocks the
  response before your code ever sees it. Check the browser console's
  Network tab first if this happens — it will show either a 404/wrong
  host or a CORS error.

## What's built so far

- Login (JWT, stored in localStorage)
- Dashboard (project counts + recent audit activity)
- Projects (list + create)
- Sidebar navigation for every planned module — pages not yet built show
  a "قيد الإنشاء" placeholder so routing/nav is complete end-to-end

## Still to build

Users/Roles, Documents, Engineer Takeoff (with lock/revision UI),
AI Takeoff, Blind VERIFY, Pricing, Procurement (PR/PO/GRN/Material
Issue), Approvals, Audit Log — the backend endpoints for all of these
already exist; only the UI is pending.
