import { NavLink, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

const NAV_SECTIONS = [
  {
    label: "عام",
    items: [
      { to: "/", label: "لوحة التحكم", end: true },
      { to: "/projects", label: "المشاريع" },
      { to: "/users", label: "المستخدمون والأدوار" },
    ],
  },
  {
    label: "الحصر والتحقق",
    items: [
      { to: "/documents", label: "المستندات" },
      { to: "/engineer-takeoffs", label: "الحصر الهندسي" },
      { to: "/ai-takeoffs", label: "الحصر بالذكاء الاصطناعي" },
      { to: "/verify", label: "التحقق الأعمى (VERIFY)" },
    ],
  },
  {
    label: "التسعير والمشتريات",
    items: [
      { to: "/pricing", label: "التسعير" },
      { to: "/procurement", label: "المشتريات" },
    ],
  },
  {
    label: "الحوكمة",
    items: [
      { to: "/approvals", label: "الموافقات" },
      { to: "/audit", label: "سجل التدقيق" },
    ],
  },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const location = useLocation();

  return (
    <div style={{ display: "flex", minHeight: "100%" }}>
      <aside
        style={{
          width: "var(--sidebar-width)",
          flexShrink: 0,
          background: "var(--nhj-blueprint-dark)",
          color: "#fff",
          padding: "20px 0",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div style={{ padding: "0 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.12)" }}>
          <h1 style={{ fontSize: 18, color: "#fff" }}>NHJ AI</h1>
          <p style={{ margin: "4px 0 0", fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
            منصة الإنشاءات
          </p>
        </div>

        <nav style={{ flex: 1, padding: "16px 12px", overflowY: "auto" }}>
          {NAV_SECTIONS.map((section) => (
            <div key={section.label} style={{ marginBottom: 18 }}>
              <p
                style={{
                  fontSize: 11,
                  color: "rgba(255,255,255,0.45)",
                  margin: "0 8px 6px",
                }}
              >
                {section.label}
              </p>
              {section.items.filter((item) => item.to !== "/users" || user?.role?.name === "admin").map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  style={({ isActive }) => ({
                    display: "block",
                    padding: "8px 12px",
                    borderRadius: 3,
                    fontSize: 14,
                    color: isActive ? "#fff" : "rgba(255,255,255,0.75)",
                    background: isActive ? "rgba(255,255,255,0.12)" : "transparent",
                    textDecoration: "none",
                    marginBottom: 2,
                  })}
                >
                  {item.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
      </aside>

      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <header
          style={{
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            gap: 16,
            padding: "14px 24px",
            background: "var(--nhj-surface)",
            borderBottom: "1px solid var(--nhj-line)",
          }}
        >
          <div style={{ textAlign: "end" }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{user?.full_name}</div>
            <div style={{ fontSize: 12, color: "var(--nhj-steel)" }}>{user?.role?.name}</div>
          </div>
          <NavLink className="btn btn--ghost" to="/account" style={{ textDecoration: "none" }}>
            إعدادات الحساب
          </NavLink>
          <button className="btn btn--ghost" onClick={logout}>
            تسجيل الخروج
          </button>
        </header>

        <main style={{ flex: 1, padding: 24 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
