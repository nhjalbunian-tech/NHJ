import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

function passwordChecks(value) {
  return {
    length: value.length >= 12,
    upper: /[A-Z]/.test(value),
    lower: /[a-z]/.test(value),
    number: /\d/.test(value),
    special: /[^A-Za-z0-9]/.test(value),
  };
}

export default function ChangePassword() {
  const { user, changePassword } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const forced = Boolean(location.state?.forced || user?.must_change_password);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const checks = passwordChecks(newPassword);
  const strong = Object.values(checks).every(Boolean);

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!strong) {
      setError("اختر كلمة مرور تستوفي جميع شروط القوة.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("تأكيد كلمة المرور غير مطابق.");
      return;
    }
    setSaving(true);
    try {
      await changePassword(currentPassword, newPassword);
      navigate("/", { replace: true });
    } catch (err) {
      setError(err.response?.data?.detail || "تعذر تغيير كلمة المرور.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div style={{ minHeight: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--nhj-paper)" }}>
      <form onSubmit={submit} className="panel" style={{ width: 440, padding: 28, borderInlineStart: "4px solid var(--nhj-blueprint)" }}>
        <p className="title-block__label">NHJ AI · الأمان</p>
        <h2 style={{ marginBottom: 8 }}>تغيير كلمة المرور</h2>
        {forced && (
          <p style={{ color: "var(--nhj-ink-soft)", marginBottom: 20 }}>
            هذه أول مرة تدخل فيها بحسابك. يجب تعيين كلمة مرور جديدة قبل متابعة استخدام المنصة.
          </p>
        )}

        <div className="field">
          <label htmlFor="currentPassword">كلمة المرور الحالية</label>
          <input id="currentPassword" type="password" required value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} autoComplete="current-password" />
        </div>

        <div className="field">
          <label htmlFor="newPassword">كلمة المرور الجديدة</label>
          <input id="newPassword" type="password" required value={newPassword} onChange={(e) => setNewPassword(e.target.value)} autoComplete="new-password" />
        </div>

        <ul style={{ fontSize: 12, paddingInlineStart: 20, lineHeight: 1.9, marginTop: -4, marginBottom: 14 }}>
          <li>12 حرفًا على الأقل {checks.length ? "✓" : "—"}</li>
          <li>حرف كبير وحرف صغير {checks.upper && checks.lower ? "✓" : "—"}</li>
          <li>رقم {checks.number ? "✓" : "—"}</li>
          <li>رمز خاص {checks.special ? "✓" : "—"}</li>
        </ul>

        <div className="field">
          <label htmlFor="confirmPassword">تأكيد كلمة المرور الجديدة</label>
          <input id="confirmPassword" type="password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} autoComplete="new-password" />
        </div>

        {error && <p className="error-text" style={{ marginBottom: 14 }}>{error}</p>}

        <button className="btn btn--primary" type="submit" disabled={saving || !strong || newPassword !== confirmPassword} style={{ width: "100%" }}>
          {saving ? "جارٍ الحفظ…" : "حفظ كلمة المرور"}
        </button>
      </form>
    </div>
  );
}
