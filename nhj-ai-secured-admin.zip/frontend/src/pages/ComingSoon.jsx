export default function ComingSoon({ title }) {
  return (
    <div>
      <div className="title-block">
        <div>
          <p className="title-block__label">قيد الإنشاء</p>
          <h2 className="title-block__value">{title}</h2>
        </div>
      </div>
      <div className="panel">
        <div className="empty-state">
          هذه الواجهة لم تُبنَ بعد — قادمة في الدفعة التالية من العمل على الواجهة الأمامية.
        </div>
      </div>
    </div>
  );
}
