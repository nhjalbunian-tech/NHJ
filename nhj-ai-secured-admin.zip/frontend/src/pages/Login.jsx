import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const loggedInUser = await login(username, password);
      navigate(loggedInUser.must_change_password ? "/change-password" : "/");
    } catch (err) {
      setError(
        err.response?.status === 401
          ? "البريد الإلكتروني أو كلمة المرور غير صحيحة"
          : "تعذر تسجيل الدخول، حاول مرة أخرى"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--nhj-paper)",
      }}
    >
      <form
        onSubmit={handleSubmit}
        className="panel"
        style={{ width: 360, padding: 28, borderInlineStart: "4px solid var(--nhj-blueprint)" }}
      >
        <p className="title-block__label" style={{ marginBottom: 2 }}>
          NHJ AI
        </p>
        <h2 style={{ marginBottom: 22 }}>تسجيل الدخول</h2>

        <div className="field">
          <label htmlFor="username">اسم المستخدم</label>
          <input
            id="username"
            type="text"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoFocus
            autoComplete="username"
          />
        </div>

        <div className="field">
          <label htmlFor="password">كلمة المرور</label>
          <input
            id="password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        {error && (
          <p className="error-text" style={{ marginBottom: 14 }}>
            {error}
          </p>
        )}

        <button className="btn btn--primary" type="submit" disabled={submitting} style={{ width: "100%" }}>
          {submitting ? "جارٍ الدخول…" : "دخول"}
        </button>
      </form>
    </div>
  );
}
