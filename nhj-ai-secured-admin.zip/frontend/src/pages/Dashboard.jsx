import { useEffect, useState } from "react";
import { api } from "../api/client";

export default function Dashboard() {
  const [projects, setProjects] = useState([]);
  const [auditEntries, setAuditEntries] = useState([]);
  const [loadError, setLoadError] = useState("");

  useEffect(() => {
    Promise.all([
      api.get("/projects").catch(() => ({ data: [] })),
      api.get("/audit").catch(() => ({ data: [] })),
    ])
      .then(([projectsRes, auditRes]) => {
        setProjects(projectsRes.data);
        setAuditEntries(auditRes.data.slice(0, 8));
      })
      .catch(() => setLoadError("تعذر تحميل بيانات لوحة التحكم"));
  }, []);

  const activeCount = projects.filter((p) => p.status === "active").length;

  return (
    <div>
      <div className="title-block">
        <div>
          <p className="title-block__label">لوحة التحكم</p>
          <h2 className="title-block__value">نظرة عامة على المنصة</h2>
        </div>
      </div>

      {loadError && <p className="error-text">{loadError}</p>}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 20 }}>
        <StatCard label="إجمالي المشاريع" value={projects.length} />
        <StatCard label="مشاريع نشطة" value={activeCount} />
        <StatCard label="آخر أحداث السجل" value={auditEntries.length} />
      </div>

      <div className="panel">
        <div className="panel__header">آخر نشاط في سجل التدقيق</div>
        {auditEntries.length === 0 ? (
          <div className="empty-state">لا يوجد نشاط مسجل بعد</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>الكيان</th>
                <th>الإجراء</th>
                <th>الوقت</th>
              </tr>
            </thead>
            <tbody>
              {auditEntries.map((entry) => (
                <tr key={entry.id}>
                  <td>
                    {entry.entity_type} <span style={{ color: "var(--nhj-steel)" }}>#{entry.entity_id.slice(0, 8)}</span>
                  </td>
                  <td>
                    <span className="tag tag--neutral">{entry.action}</span>
                  </td>
                  <td className="numeral">{new Date(entry.timestamp).toLocaleString("ar")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="panel" style={{ padding: "16px 20px" }}>
      <p style={{ fontSize: 12, color: "var(--nhj-steel)", margin: "0 0 6px" }}>{label}</p>
      <p className="numeral" style={{ fontSize: 28, fontWeight: 700, margin: 0 }}>
        {value}
      </p>
    </div>
  );
}
