import { useEffect, useState } from "react";
import { api } from "../api/client";

const STATUS_LABELS = { planning: "تخطيط", active: "نشط", on_hold: "متوقف", closed: "مغلق" };
const EMPTY_FORM = { code: "", name: "", client_name: "", location: "", status: "planning" };

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try { setProjects((await api.get("/projects")).data); }
    catch (err) { setError(err.response?.data?.detail || "تعذر تحميل المشاريع"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, []);

  function openCreate() { setEditing(null); setForm(EMPTY_FORM); setShowForm(true); setError(""); }
  function openEdit(project) { setEditing(project); setForm({ code: project.code, name: project.name, client_name: project.client_name || "", location: project.location || "", status: project.status }); setShowForm(true); setError(""); }
  function closeForm() { setShowForm(false); setEditing(null); setForm(EMPTY_FORM); }

  async function submit(e) {
    e.preventDefault(); setError("");
    try {
      if (editing) { await api.patch(`/projects/${editing.id}`, { name: form.name, client_name: form.client_name, location: form.location, status: form.status }); setNotice("تم تحديث المشروع"); }
      else { await api.post("/projects", form); setNotice("تم إنشاء المشروع"); }
      closeForm(); await load();
    } catch (err) { setError(err.response?.data?.detail || "تعذر حفظ المشروع"); }
  }

  return <div>
    <div className="title-block"><div><p className="title-block__label">المشاريع</p><h2 className="title-block__value">{projects.length} مشروع</h2></div><button className="btn btn--primary" onClick={openCreate}>+ مشروع جديد</button></div>
    {notice && <p className="success-text">{notice}</p>}{error && <p className="error-text">{error}</p>}
    {showForm && <form onSubmit={submit} className="panel" style={{ padding: 20, marginBottom: 20 }}><div className="panel__header">{editing ? "تعديل المشروع" : "مشروع جديد"}</div><div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
      <div className="field"><label>رمز المشروع</label><input required disabled={Boolean(editing)} value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} /></div><div className="field"><label>اسم المشروع</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div><div className="field"><label>العميل</label><input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} /></div><div className="field"><label>الموقع</label><input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>{editing && <div className="field"><label>الحالة</label><select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>{Object.entries(STATUS_LABELS).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></div>}
    </div><div style={{ display: "flex", gap: 10, marginTop: 16 }}><button className="btn btn--primary">حفظ</button><button type="button" className="btn btn--ghost" onClick={closeForm}>إلغاء</button></div></form>}
    <div className="panel">{loading ? <div className="empty-state">جارٍ التحميل…</div> : projects.length === 0 ? <div className="empty-state">لا توجد مشاريع بعد — أنشئ أول مشروع للبدء.</div> : <table className="data-table"><thead><tr><th>الرمز</th><th>الاسم</th><th>العميل</th><th>الموقع</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>{projects.map((p) => <tr key={p.id}><td className="numeral">{p.code}</td><td>{p.name}</td><td>{p.client_name || "—"}</td><td>{p.location || "—"}</td><td><span className="tag tag--neutral">{STATUS_LABELS[p.status] || p.status}</span></td><td><button className="btn btn--ghost" onClick={() => openEdit(p)}>تعديل</button></td></tr>)}</tbody></table>}</div>
  </div>;
}
