import { useEffect, useState } from "react";
import { api } from "../api/client";

const EMPTY_FORM = { username: "", email: "", full_name: "", password: "", role_name: "engineer" };
const ROLE_LABELS = {
  admin: "مدير النظام",
  project_manager: "مدير مشاريع",
  engineer: "مهندس",
  ai_agent: "وكيل ذكاء اصطناعي",
  estimator: "مسعّر",
  procurement: "مشتريات",
  verifier: "متحقق",
  auditor: "مدقق",
};

export default function Users() {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editing, setEditing] = useState(null);
  const [resetTarget, setResetTarget] = useState(null);
  const [resetPassword, setResetPassword] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [usersRes, rolesRes] = await Promise.all([api.get("/users"), api.get("/users/roles")]);
      setUsers(usersRes.data);
      setRoles(rolesRes.data);
    } catch (err) {
      setError(err.response?.data?.detail || "تعذر تحميل المستخدمين");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  function startEdit(user) {
    setEditing(user);
    setForm({ username: user.username || "", email: user.email, full_name: user.full_name, password: "", role_name: user.role.name });
    setShowForm(true);
    setError("");
  }

  function closeForm() {
    setShowForm(false);
    setEditing(null);
    setForm(EMPTY_FORM);
    setError("");
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    try {
      if (editing) {
        await api.patch(`/users/${editing.id}`, {
          username: form.username,
          email: form.email,
          full_name: form.full_name,
          role_name: form.role_name,
        });
        setNotice("تم تحديث بيانات العضو");
      } else {
        await api.post("/users", form);
        setNotice("تمت إضافة العضو. سيُطلب منه تغيير كلمة المرور عند أول دخول.");
      }
      closeForm();
      await load();
    } catch (err) {
      setError(err.response?.data?.detail || "تعذر حفظ بيانات العضو");
    }
  }

  async function toggleActive(user) {
    setError("");
    try {
      await api.patch(`/users/${user.id}`, { is_active: !user.is_active });
      setNotice(user.is_active ? "تم تعطيل العضو" : "تم تفعيل العضو");
      await load();
    } catch (err) {
      setError(err.response?.data?.detail || "تعذر تحديث حالة العضو");
    }
  }

  async function submitReset(e) {
    e.preventDefault();
    try {
      await api.post(`/users/${resetTarget.id}/reset-password`, { new_password: resetPassword });
      setResetTarget(null);
      setResetPassword("");
      setNotice("تمت إعادة تعيين كلمة المرور، وسيُطلب من العضو تغييرها عند الدخول التالي.");
      await load();
    } catch (err) {
      setError(err.response?.data?.detail || "تعذر إعادة تعيين كلمة المرور");
    }
  }

  return (
    <div>
      <div className="title-block">
        <div>
          <p className="title-block__label">الإدارة والصلاحيات</p>
          <h2 className="title-block__value">{users.length} عضو</h2>
        </div>
        <button className="btn btn--primary" onClick={() => { setEditing(null); setForm(EMPTY_FORM); setShowForm(true); }}>
          + إضافة عضو
        </button>
      </div>

      {notice && <p className="success-text">{notice}</p>}
      {error && <p className="error-text">{error}</p>}

      {showForm && (
        <form onSubmit={submit} className="panel" style={{ padding: 20, marginBottom: 20 }}>
          <div className="panel__header">{editing ? "تعديل بيانات العضو" : "إضافة عضو جديد"}</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div className="field"><label>اسم المستخدم</label><input required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></div>
            <div className="field"><label>الاسم الكامل</label><input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
            <div className="field"><label>البريد الإلكتروني</label><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="field"><label>الدور</label><select value={form.role_name} onChange={(e) => setForm({ ...form, role_name: e.target.value })}>{roles.map((r) => <option key={r.id} value={r.name}>{ROLE_LABELS[r.name] || r.name}</option>)}</select></div>
            {!editing && <div className="field"><label>كلمة المرور الأولية</label><input required type="password" minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>}
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 16 }}><button className="btn btn--primary" type="submit">حفظ</button><button className="btn btn--ghost" type="button" onClick={closeForm}>إلغاء</button></div>
        </form>
      )}

      <div className="panel">
        {loading ? <div className="empty-state">جارٍ التحميل…</div> : users.length === 0 ? <div className="empty-state">لا يوجد أعضاء بعد.</div> : (
          <table className="data-table"><thead><tr><th>العضو</th><th>البريد</th><th>الدور</th><th>الحالة</th><th>الإجراءات</th></tr></thead>
            <tbody>{users.map((user) => <tr key={user.id}>
              <td><strong>{user.full_name}</strong><br /><small>{user.username}</small></td>
              <td>{user.email}</td>
              <td><span className="tag tag--neutral">{ROLE_LABELS[user.role.name] || user.role.name}</span></td>
              <td><span className={`tag ${user.is_active ? "tag--success" : "tag--neutral"}`}>{user.is_active ? "نشط" : "معطل"}</span>{user.must_change_password && <><br /><small>بانتظار تغيير كلمة المرور</small></>}</td>
              <td><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}><button className="btn btn--ghost" onClick={() => startEdit(user)}>تعديل</button><button className="btn btn--ghost" onClick={() => setResetTarget(user)}>إعادة كلمة المرور</button><button className="btn btn--ghost" onClick={() => toggleActive(user)}>{user.is_active ? "تعطيل" : "تفعيل"}</button></div></td>
            </tr>)}</tbody>
          </table>
        )}
      </div>

      {resetTarget && <div className="modal-backdrop"><form className="panel modal" onSubmit={submitReset}><h3>إعادة كلمة مرور {resetTarget.full_name}</h3><div className="field"><label>كلمة المرور الجديدة</label><input autoFocus required minLength={8} type="password" value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} /></div><div style={{ display: "flex", gap: 10 }}><button className="btn btn--primary">تأكيد</button><button type="button" className="btn btn--ghost" onClick={() => setResetTarget(null)}>إلغاء</button></div></form></div>}
    </div>
  );
}
