import { useState } from "react";
import { useAuth } from "../auth/AuthContext";

export default function AccountSettings() {
  const { changePassword } = useAuth();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setMessage("");
    setError("");
    if (newPassword !== confirmPassword) {
      setError("تأكيد كلمة المرور غير مطابق.");
      return;
    }
    try {
      await changePassword(currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setMessage("تم تغيير كلمة المرور بنجاح.");
    } catch (err) {
      setError(err.response?.data?.detail || "تعذر تغيير كلمة المرور.");
    }
  }

  return (
    <div>
      <div className="title-block">
        <div>
          <p className="title-block__label">الحساب</p>
          <h2 className="title-block__value">إعدادات الحساب</h2>
        </div>
      </div>
      <div className="panel" style={{ maxWidth: 620, padding: 24 }}>
        <h3 style={{ marginTop: 0 }}>الأمان</h3>
        <p style={{ color: "var(--nhj-ink-soft)" }}>تغيير كلمة المرور الخاصة بحسابك.</p>
        <form onSubmit={submit}>
          <div className="field">
            <label>كلمة المرور الحالية</label>
            <input type="password" required value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
          </div>
          <div className="field">
            <label>كلمة المرور الجديدة</label>
            <input type="password" required minLength={12} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          </div>
          <div className="field">
            <label>تأكيد كلمة المرور الجديدة</label>
            <input type="password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
          </div>
          {error && <p className="error-text">{error}</p>}
          {message && <p style={{ color: "var(--nhj-green)" }}>{message}</p>}
          <button className="btn btn--primary" type="submit">تغيير كلمة المرور</button>
        </form>
      </div>
    </div>
  );
}
