import { Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import ProtectedRoute from "./auth/ProtectedRoute";
import Layout from "./components/Layout";
import AITakeoffs from "./pages/ComingSoon";
import Approvals from "./pages/ComingSoon";
import Audit from "./pages/ComingSoon";
import Dashboard from "./pages/Dashboard";
import Documents from "./pages/ComingSoon";
import EngineerTakeoffs from "./pages/ComingSoon";
import Login from "./pages/Login";
import ChangePassword from "./pages/ChangePassword";
import AccountSettings from "./pages/AccountSettings";
import Pricing from "./pages/ComingSoon";
import Procurement from "./pages/ComingSoon";
import Projects from "./pages/Projects";
import Users from "./pages/Users";
import Verify from "./pages/ComingSoon";

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/change-password" element={<ProtectedRoute><ChangePassword /></ProtectedRoute>} />

        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="projects" element={<Projects />} />
          <Route path="users" element={<Users title="المستخدمون والأدوار" />} />
          <Route path="account" element={<AccountSettings />} />
          <Route path="documents" element={<Documents title="المستندات" />} />
          <Route path="engineer-takeoffs" element={<EngineerTakeoffs title="الحصر الهندسي" />} />
          <Route path="ai-takeoffs" element={<AITakeoffs title="الحصر بالذكاء الاصطناعي" />} />
          <Route path="verify" element={<Verify title="التحقق الأعمى (VERIFY)" />} />
          <Route path="pricing" element={<Pricing title="التسعير" />} />
          <Route path="procurement" element={<Procurement title="المشتريات" />} />
          <Route path="approvals" element={<Approvals title="الموافقات" />} />
          <Route path="audit" element={<Audit title="سجل التدقيق" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </AuthProvider>
  );
}
