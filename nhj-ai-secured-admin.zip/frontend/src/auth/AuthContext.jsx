import { createContext, useContext, useEffect, useState } from "react";
import { api } from "../api/client";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("nhj_token");
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get("/users/me")
      .then((res) => setUser(res.data))
      .catch(() => localStorage.removeItem("nhj_token"))
      .finally(() => setLoading(false));
  }, []);

  async function login(email, password) {
    // The backend's /auth/login uses OAuth2PasswordRequestForm, which
    // expects application/x-www-form-urlencoded with a "username" field
    // (even though it's an email here) — not JSON.
    const form = new URLSearchParams();
    form.set("username", email);
    form.set("password", password);

    const { data } = await api.post("/auth/login", form, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
    localStorage.setItem("nhj_token", data.access_token);

    const me = await api.get("/users/me");
    setUser(me.data);
    return me.data;
  }

  function logout() {
    localStorage.removeItem("nhj_token");
    setUser(null);
  }

  async function changePassword(currentPassword, newPassword) {
    const { data } = await api.post("/auth/change-password", {
      current_password: currentPassword,
      new_password: newPassword,
    });
    setUser(data);
    return data;
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, changePassword }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
