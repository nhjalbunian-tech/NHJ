import axios from "axios";

// In dev, Vite's proxy (see vite.config.js) forwards "/api/*" to the
// FastAPI backend, so the relative default works with no configuration.
// In production, if the frontend is NOT served from the same origin as
// the backend, set VITE_API_BASE_URL (e.g. https://api.example.com/api/v1)
// at build time — otherwise every request silently 404s and the UI looks
// like it "does nothing" on submit, which is one of the likelier causes
// behind a login button that appears unresponsive after deployment.
const baseURL = import.meta.env.VITE_API_BASE_URL || "/api/v1";

export const api = axios.create({ baseURL });


api.interceptors.request.use((config) => {
  const token = localStorage.getItem("nhj_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("nhj_token");
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);
