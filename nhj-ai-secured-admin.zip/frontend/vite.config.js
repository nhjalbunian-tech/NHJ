import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// Proxies /api/* to the FastAPI backend during development so the
// frontend can call relative paths without hardcoding a host/port.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
      },
    },
  },
});
