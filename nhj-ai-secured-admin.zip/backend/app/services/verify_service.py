from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.takeoff import AITakeoff, EngineerTakeoffRevision
from app.models.verify import VerificationLine, VerificationSession, VerificationStatus
from app.services import audit_service


def start_session(
    db: Session,
    *,
    project_id: str,
    engineer_revision: EngineerTakeoffRevision,
    ai_takeoff: AITakeoff,
    verifier_id: str,
) -> VerificationSession:
    """
    Pairs up an engineer revision's lines with the AI takeoff's lines by
    position. Real matching (by item_code/description similarity) can
    replace this later without changing the blind-reveal contract below.
    """
    session = VerificationSession(
        project_id=project_id,
        engineer_revision_id=engineer_revision.id,
        ai_takeoff_id=ai_takeoff.id,
        verifier_id=verifier_id,
        status=VerificationStatus.pending,
    )
    db.add(session)
    db.flush()

    eng_lines = list(engineer_revision.lines)
    ai_lines = list(ai_takeoff.lines)
    for i in range(max(len(eng_lines), len(ai_lines))):
        eng_line = eng_lines[i] if i < len(eng_lines) else None
        ai_line = ai_lines[i] if i < len(ai_lines) else None
        db.add(
            VerificationLine(
                session_id=session.id,
                item_code=(eng_line or ai_line).item_code,
                description=(eng_line or ai_line).description,
                engineer_qty=eng_line.quantity if eng_line else 0.0,
                ai_qty=ai_line.quantity if ai_line else 0.0,
            )
        )

    audit_service.record(
        db, entity_type="verification_session", entity_id=session.id, action="create",
        actor_id=verifier_id, after={"engineer_revision_id": engineer_revision.id, "ai_takeoff_id": ai_takeoff.id},
    )
    db.commit()
    db.refresh(session)
    return session


def submit_verifier_qty(
    db: Session, *, line: VerificationLine, verifier_qty: float, actor_id: str
) -> VerificationLine:
    """
    The one moment where the blind is lifted: only once verifier_qty is
    set do we compute and expose variance. VerificationLineBlindRead
    (the schema used before this call) never carries engineer_qty/ai_qty
    to the client, so the verifier cannot have seen them beforehand.
    """
    if line.verifier_qty is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Verifier quantity already submitted for this line")

    line.verifier_qty = verifier_qty
    base = line.engineer_qty if line.engineer_qty else line.ai_qty
    if base:
        avg_reference = (line.engineer_qty + line.ai_qty) / 2
        line.variance_pct = (
            abs(verifier_qty - avg_reference) / avg_reference * 100 if avg_reference else 0.0
        )
    else:
        line.variance_pct = 0.0
    line.flagged = line.variance_pct is not None and line.variance_pct > 10.0

    audit_service.record(
        db, entity_type="verification_line", entity_id=line.id, action="submit_blind_qty",
        actor_id=actor_id, after={"verifier_qty": verifier_qty, "variance_pct": line.variance_pct},
    )
    db.commit()
    db.refresh(line)
    return line
