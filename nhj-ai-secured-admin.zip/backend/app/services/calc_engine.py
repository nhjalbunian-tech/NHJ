from sqlalchemy.orm import Session

from app.models.units import UnitConversion, UnitOfMeasure


class ConversionError(Exception):
    pass


def convert(db: Session, value: float, from_unit_code: str, to_unit_code: str) -> float:
    """
    Converts `value` from one unit to another using the UnitConversion
    table. Same-unit conversions are a no-op; cross-category conversions
    (e.g. length -> weight) always raise, since there is no physically
    meaningful factor for them.
    """
    if from_unit_code == to_unit_code:
        return value

    from_unit = db.query(UnitOfMeasure).filter(UnitOfMeasure.code == from_unit_code).first()
    to_unit = db.query(UnitOfMeasure).filter(UnitOfMeasure.code == to_unit_code).first()
    if from_unit is None or to_unit is None:
        raise ConversionError(f"Unknown unit code: {from_unit_code} or {to_unit_code}")
    if from_unit.category != to_unit.category:
        raise ConversionError(
            f"Cannot convert across categories: {from_unit.category} -> {to_unit.category}"
        )

    direct = (
        db.query(UnitConversion)
        .filter(UnitConversion.from_unit_id == from_unit.id, UnitConversion.to_unit_id == to_unit.id)
        .first()
    )
    if direct:
        return value * direct.factor

    # Fall back to the inverse of a recorded conversion in the other direction.
    inverse = (
        db.query(UnitConversion)
        .filter(UnitConversion.from_unit_id == to_unit.id, UnitConversion.to_unit_id == from_unit.id)
        .first()
    )
    if inverse:
        return value / inverse.factor

    raise ConversionError(f"No conversion factor registered for {from_unit_code} -> {to_unit_code}")


def extend_quantity(quantity: float, unit_rate: float) -> float:
    """Basic estimating primitive: quantity x rate = extended cost."""
    return quantity * unit_rate
