import json
from typing import Any

from sqlalchemy.orm import Session

from app.models.audit import AuditLog


def record(
    db: Session,
    *,
    entity_type: str,
    entity_id: str,
    action: str,
    actor_id: str | None,
    before: dict[str, Any] | None = None,
    after: dict[str, Any] | None = None,
) -> AuditLog:
    """
    Insert one immutable audit entry. Callers pass plain dicts for
    before/after; they're JSON-serialized here. There is intentionally no
    update() or delete() in this module — correcting the record means
    inserting a new entry, never touching an old one.
    """
    entry = AuditLog(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        actor_id=actor_id,
        before_state=json.dumps(before, default=str) if before is not None else "",
        after_state=json.dumps(after, default=str) if after is not None else "",
    )
    db.add(entry)
    db.flush()
    return entry
