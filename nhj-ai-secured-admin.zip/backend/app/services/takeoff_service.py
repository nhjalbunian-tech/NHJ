from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.takeoff import (
    EngineerTakeoff,
    EngineerTakeoffLine,
    EngineerTakeoffRevision,
    TakeoffStatus,
)
from app.schemas.takeoff import TakeoffLineIn
from app.services import audit_service


def create_takeoff(
    db: Session, *, project_id: str, discipline: str, title: str, lines: list[TakeoffLineIn], user_id: str
) -> EngineerTakeoff:
    takeoff = EngineerTakeoff(
        project_id=project_id, discipline=discipline, title=title, created_by_id=user_id
    )
    db.add(takeoff)
    db.flush()

    revision = EngineerTakeoffRevision(
        takeoff_id=takeoff.id, revision_number=1, status=TakeoffStatus.draft, created_by_id=user_id
    )
    db.add(revision)
    db.flush()

    for line in lines:
        db.add(EngineerTakeoffLine(revision_id=revision.id, **line.model_dump()))

    audit_service.record(
        db, entity_type="engineer_takeoff", entity_id=takeoff.id, action="create",
        actor_id=user_id, after={"title": title, "discipline": discipline, "revision": 1},
    )
    db.commit()
    db.refresh(takeoff)
    return takeoff


def current_revision(takeoff: EngineerTakeoff) -> EngineerTakeoffRevision:
    return next(r for r in takeoff.revisions if r.revision_number == takeoff.current_revision_number)


def lock_revision(db: Session, *, takeoff: EngineerTakeoff, user_id: str) -> EngineerTakeoffRevision:
    revision = current_revision(takeoff)
    if revision.is_locked:
        raise HTTPException(status.HTTP_409_CONFLICT, "This revision is already locked")

    revision.status = TakeoffStatus.locked
    revision.locked_at = datetime.now(timezone.utc)
    revision.locked_by_id = user_id

    audit_service.record(
        db, entity_type="engineer_takeoff_revision", entity_id=revision.id, action="lock",
        actor_id=user_id, before={"status": "draft"}, after={"status": "locked"},
    )
    db.commit()
    db.refresh(revision)
    return revision


def create_revision(
    db: Session, *, takeoff: EngineerTakeoff, lines: list[TakeoffLineIn], notes: str, user_id: str
) -> EngineerTakeoffRevision:
    """
    Only callable once the current revision is locked. The previous
    revision is marked `superseded` (still fully intact and readable) and
    a fresh `draft` revision is created with the caller-supplied lines —
    nothing is ever edited or deleted in place.
    """
    prior = current_revision(takeoff)
    if not prior.is_locked:
        raise HTTPException(
            status.HTTP_409_CONFLICT, "Lock the current revision before creating a new one"
        )

    prior.status = TakeoffStatus.superseded

    new_number = takeoff.current_revision_number + 1
    new_revision = EngineerTakeoffRevision(
        takeoff_id=takeoff.id,
        revision_number=new_number,
        status=TakeoffStatus.draft,
        notes=notes,
        created_by_id=user_id,
    )
    db.add(new_revision)
    db.flush()

    for line in lines:
        db.add(EngineerTakeoffLine(revision_id=new_revision.id, **line.model_dump()))

    takeoff.current_revision_number = new_number

    audit_service.record(
        db, entity_type="engineer_takeoff", entity_id=takeoff.id, action="new_revision",
        actor_id=user_id, before={"revision": prior.revision_number}, after={"revision": new_number},
    )
    db.commit()
    db.refresh(new_revision)
    return new_revision
