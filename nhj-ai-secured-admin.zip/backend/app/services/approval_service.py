from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.approval import ApprovalRequest, ApprovalStatus, ApprovalStep
from app.services import audit_service


def create_request(
    db: Session, *, entity_type: str, entity_id: str, steps: list[dict], requested_by_id: str
) -> ApprovalRequest:
    request = ApprovalRequest(entity_type=entity_type, entity_id=entity_id, requested_by_id=requested_by_id)
    db.add(request)
    db.flush()

    for step in steps:
        db.add(ApprovalStep(request_id=request.id, **step))

    audit_service.record(
        db, entity_type="approval_request", entity_id=request.id, action="create",
        actor_id=requested_by_id, after={"entity_type": entity_type, "entity_id": entity_id},
    )
    db.commit()
    db.refresh(request)
    return request


def act_on_step(
    db: Session, *, request: ApprovalRequest, approve: bool, comments: str, actor_id: str
) -> ApprovalRequest:
    step = next((s for s in request.steps if s.step_order == request.current_step_order), None)
    if step is None or step.status != ApprovalStatus.pending:
        raise HTTPException(status.HTTP_409_CONFLICT, "No pending step to act on")

    step.status = ApprovalStatus.approved if approve else ApprovalStatus.rejected
    step.acted_by_id = actor_id
    step.acted_at = datetime.now(timezone.utc)
    step.comments = comments

    if not approve:
        request.status = ApprovalStatus.rejected
    else:
        remaining = [s for s in request.steps if s.step_order > step.step_order]
        if remaining:
            request.current_step_order = min(s.step_order for s in remaining)
        else:
            request.status = ApprovalStatus.approved

    audit_service.record(
        db, entity_type="approval_step", entity_id=step.id, action="approve" if approve else "reject",
        actor_id=actor_id, after={"comments": comments},
    )
    db.commit()
    db.refresh(request)
    return request
