from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password, validate_password_strength
from app.db.base_class import Base
from app.db.session import engine
from app.models.units import DEFAULT_CONVERSIONS, DEFAULT_UNITS, UnitConversion, UnitOfMeasure
from app.models.user import DEFAULT_ROLES, Role, User

# Importing app.models (via app.models.__init__) registers every model
# class on Base.metadata before create_all runs.
import app.models  # noqa: F401,E402


def _ensure_auth_columns(db: Session) -> None:
    """Small v0.1 compatibility migration for existing SQLite/Postgres databases."""
    inspector = inspect(engine)
    columns = {c["name"] for c in inspector.get_columns("users")} if inspector.has_table("users") else set()
    if "username" not in columns:
        db.execute(text("ALTER TABLE users ADD COLUMN username VARCHAR(100)"))
    if "must_change_password" not in columns:
        db.execute(text("ALTER TABLE users ADD COLUMN must_change_password BOOLEAN NOT NULL DEFAULT TRUE"))
    db.commit()
    # Backfill usernames for users created by v0.1.0.
    db.execute(text("""
        UPDATE users
        SET username = lower(substr(email, 1, instr(email, '@') - 1))
        WHERE username IS NULL OR username = ''
    """))
    db.commit()


def init_db(db: Session) -> None:
    Base.metadata.create_all(bind=engine)
    _ensure_auth_columns(db)
    _seed_roles(db)
    _seed_units(db)
    _seed_admin_user(db)


def _seed_roles(db: Session) -> None:
    for role_def in DEFAULT_ROLES:
        exists = db.query(Role).filter(Role.name == role_def["name"]).first()
        if not exists:
            db.add(Role(**role_def))
    db.commit()


def _seed_units(db: Session) -> None:
    if db.query(UnitOfMeasure).count() > 0:
        return
    code_to_id = {}
    for unit_def in DEFAULT_UNITS:
        unit = UnitOfMeasure(**unit_def)
        db.add(unit)
        db.flush()
        code_to_id[unit.code] = unit.id
    for from_code, to_code, factor in DEFAULT_CONVERSIONS:
        db.add(
            UnitConversion(
                from_unit_id=code_to_id[from_code], to_unit_id=code_to_id[to_code], factor=factor
            )
        )
    db.commit()


def _seed_admin_user(db: Session) -> None:
    """
    Convenience only: creates a starter admin so the API is usable
    immediately after `uvicorn app.main:app --reload`. Change or remove
    this before any real deployment.
    """
    if db.query(User).count() > 0 or not settings.ADMIN_INITIAL_PASSWORD:
        return
    password_error = validate_password_strength(settings.ADMIN_INITIAL_PASSWORD)
    if password_error:
        raise RuntimeError(f"ADMIN_INITIAL_PASSWORD is invalid: {password_error}")
    admin_role = db.query(Role).filter(Role.name == "admin").first()
    db.add(
        User(
            username="admin",
            email="admin@nhj.local",
            full_name="System Administrator",
            hashed_password=hash_password(settings.ADMIN_INITIAL_PASSWORD),
            must_change_password=True,
            role_id=admin_role.id,
        )
    )
    db.commit()
