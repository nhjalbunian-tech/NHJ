"""
Application settings.

SQLite is used by default for local development. The DATABASE_URL is the
single point of change required to move to PostgreSQL in production
(e.g. postgresql+psycopg2://user:pass@host:5432/nhj_ai) since all models
are declared with SQLAlchemy's dialect-agnostic column types.
"""
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


BACKEND_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    PROJECT_NAME: str = "NHJ AI"
    API_V1_PREFIX: str = "/api/v1"

    # Swap this for a PostgreSQL DSN in staging/production. No other code
    # needs to change.
    DATABASE_URL: str = "sqlite:///./nhj_ai.db"

    # Secrets must be supplied through backend/.env or the deployment environment.
    SECRET_KEY: str
    ADMIN_INITIAL_PASSWORD: str | None = None
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 8  # 8 hour shift-length default

    # Restrict cross-origin requests by default; override with a comma-separated
    # list in CORS_ORIGINS when the frontend is hosted on another origin.
    CORS_ORIGINS: list[str] = ["http://localhost:5173"]

    model_config = SettingsConfigDict(
        env_file=BACKEND_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
