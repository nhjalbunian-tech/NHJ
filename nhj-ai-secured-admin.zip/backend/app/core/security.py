from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(subject: str, extra_claims: dict[str, Any] | None = None) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode: dict[str, Any] = {"sub": subject, "exp": expire}
    if extra_claims:
        to_encode.update(extra_claims)
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_access_token(token: str) -> dict[str, Any] | None:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except JWTError:
        return None


def validate_password_strength(password: str) -> str | None:
    """Return an Arabic validation message, or None when the password is strong enough."""
    if len(password) < 12:
        return "كلمة المرور يجب أن تكون 12 حرفًا على الأقل"
    if not any(c.isupper() for c in password):
        return "كلمة المرور يجب أن تحتوي على حرف إنجليزي كبير"
    if not any(c.islower() for c in password):
        return "كلمة المرور يجب أن تحتوي على حرف إنجليزي صغير"
    if not any(c.isdigit() for c in password):
        return "كلمة المرور يجب أن تحتوي على رقم"
    if not any(not c.isalnum() for c in password):
        return "كلمة المرور يجب أن تحتوي على رمز خاص"
    return None
