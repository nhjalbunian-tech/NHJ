from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.models.approval import ApprovalStatus


class ApprovalStepIn(BaseModel):
    step_order: int
    approver_role_id: str


class ApprovalRequestCreate(BaseModel):
    entity_type: str
    entity_id: str
    steps: list[ApprovalStepIn]


class ApprovalStepRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    step_order: int
    approver_role_id: str
    status: ApprovalStatus
    acted_by_id: str | None
    acted_at: datetime | None
    comments: str


class ApprovalRequestRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    entity_type: str
    entity_id: str
    status: ApprovalStatus
    current_step_order: int
    steps: list[ApprovalStepRead] = []


class ApprovalActionRequest(BaseModel):
    approve: bool
    comments: str = ""
