from datetime import date

from pydantic import BaseModel, ConfigDict

from app.models.procurement import DocStatus


class LineIn(BaseModel):
    item_code: str = ""
    description: str
    quantity: float
    unit_id: str


class PRLineIn(LineIn):
    estimated_unit_rate: float = 0.0


class POLineIn(LineIn):
    unit_rate: float = 0.0


class PurchaseRequisitionCreate(BaseModel):
    project_id: str
    pr_number: str
    lines: list[PRLineIn]


class PurchaseRequisitionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    pr_number: str
    status: DocStatus


class PurchaseOrderCreate(BaseModel):
    project_id: str
    pr_id: str | None = None
    po_number: str
    supplier_name: str
    lines: list[POLineIn]


class PurchaseOrderRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    po_number: str
    supplier_name: str
    status: DocStatus


class GRNLineIn(BaseModel):
    po_line_id: str
    quantity_received: float
    remarks: str = ""


class GoodsReceivedNoteCreate(BaseModel):
    po_id: str
    grn_number: str
    received_date: date
    lines: list[GRNLineIn]


class GoodsReceivedNoteRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    po_id: str
    grn_number: str
    status: DocStatus


class MaterialIssueLineIn(LineIn):
    source_grn_line_id: str | None = None


class MaterialIssueCreate(BaseModel):
    project_id: str
    issue_number: str
    issued_to: str
    issue_date: date
    lines: list[MaterialIssueLineIn]


class MaterialIssueRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    issue_number: str
    issued_to: str
    status: DocStatus
