from pydantic import BaseModel, ConfigDict

from app.models.verify import VerificationStatus


class VerificationSessionCreate(BaseModel):
    project_id: str
    engineer_revision_id: str
    ai_takeoff_id: str
    verifier_id: str


class VerificationLineBlindRead(BaseModel):
    """What the verifier sees BEFORE submitting: no engineer/AI figures."""
    model_config = ConfigDict(from_attributes=True)
    id: str
    item_code: str
    description: str
    verifier_qty: float | None = None


class VerificationLineFullRead(BaseModel):
    """What is returned AFTER the verifier has submitted their number."""
    model_config = ConfigDict(from_attributes=True)
    id: str
    item_code: str
    description: str
    engineer_qty: float
    ai_qty: float
    verifier_qty: float | None
    variance_pct: float | None
    flagged: bool


class SubmitVerifierQtyRequest(BaseModel):
    verifier_qty: float


class VerificationSessionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    status: VerificationStatus
