from datetime import datetime

from pydantic import BaseModel, ConfigDict


class AuditLogRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    entity_type: str
    entity_id: str
    action: str
    actor_id: str | None
    timestamp: datetime
    before_state: str
    after_state: str
