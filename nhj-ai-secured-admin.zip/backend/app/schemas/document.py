from pydantic import BaseModel, ConfigDict

from app.models.document import DocumentType


class DocumentCreate(BaseModel):
    project_id: str
    name: str
    doc_type: DocumentType
    file_path: str = ""
    file_hash: str = ""


class DocumentRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    name: str
    doc_type: DocumentType
    version: int
    file_path: str
    file_hash: str
    uploaded_by_id: str
