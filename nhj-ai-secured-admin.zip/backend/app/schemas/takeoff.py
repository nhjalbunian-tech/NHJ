from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.models.takeoff import AITakeoffStatus, TakeoffStatus


# --- Engineer takeoff --------------------------------------------------------
class TakeoffLineIn(BaseModel):
    item_code: str = ""
    description: str
    quantity: float
    unit_id: str


class TakeoffLineRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    item_code: str
    description: str
    quantity: float
    unit_id: str


class EngineerTakeoffCreate(BaseModel):
    project_id: str
    discipline: str
    title: str
    lines: list[TakeoffLineIn] = []


class RevisionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    revision_number: int
    status: TakeoffStatus
    notes: str
    locked_at: datetime | None = None
    lines: list[TakeoffLineRead] = []


class EngineerTakeoffRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    discipline: str
    title: str
    current_revision_number: int
    revisions: list[RevisionRead] = []


class ReviseTakeoffRequest(BaseModel):
    """Creates a new revision. Only valid once the current revision is locked."""
    notes: str = ""
    lines: list[TakeoffLineIn]


# --- AI takeoff ---------------------------------------------------------------
class AITakeoffLineIn(BaseModel):
    item_code: str = ""
    description: str
    quantity: float
    unit_id: str
    confidence_score: float = 0.0


class AITakeoffLineRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    item_code: str
    description: str
    quantity: float
    unit_id: str
    confidence_score: float


class AITakeoffCreate(BaseModel):
    project_id: str
    discipline: str
    title: str
    model_version: str = ""
    lines: list[AITakeoffLineIn] = []


class AITakeoffRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    discipline: str
    title: str
    model_version: str
    status: AITakeoffStatus
    lines: list[AITakeoffLineRead] = []
