from datetime import date

from pydantic import BaseModel, ConfigDict


class PriceListCreate(BaseModel):
    name: str
    currency: str = "USD"
    effective_date: date


class PriceListItemCreate(BaseModel):
    price_list_id: str
    item_code: str
    description: str
    unit_id: str
    material_rate: float = 0.0
    labor_rate: float = 0.0
    equipment_rate: float = 0.0


class PriceListItemRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    item_code: str
    description: str
    unit_id: str
    material_rate: float
    labor_rate: float
    equipment_rate: float
    total_rate: float


class PriceListRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    currency: str
    effective_date: date
    is_active: bool
