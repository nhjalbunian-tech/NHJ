from pydantic import BaseModel, ConfigDict, EmailStr


class RoleRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: str
    permissions: list[str]


class UserCreate(BaseModel):
    username: str | None = None
    email: EmailStr
    full_name: str
    password: str
    role_name: str = "engineer"


class UserUpdate(BaseModel):
    username: str | None = None
    email: EmailStr | None = None
    full_name: str | None = None
    role_name: str | None = None
    is_active: bool | None = None


class UserPasswordReset(BaseModel):
    new_password: str


class UserRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    username: str | None
    email: EmailStr
    full_name: str
    is_active: bool
    must_change_password: bool
    role: RoleRead


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    must_change_password: bool = False


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
