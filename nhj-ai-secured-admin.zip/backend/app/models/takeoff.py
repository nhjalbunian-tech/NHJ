import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin


class TakeoffStatus(str, enum.Enum):
    draft = "draft"          # current revision still editable
    locked = "locked"        # current revision frozen, immutable
    superseded = "superseded"  # a newer revision now exists


# ---------------------------------------------------------------------------
# Engineer Takeoff
#
# Model: a takeoff HEADER owns an ordered set of REVISIONS. Only one
# revision is ever editable (the header's current one) and it starts life
# as `draft`. Locking a revision (see services/takeoff_service.py) flips it
# to `locked` and stamps locked_at/locked_by — after that point the service
# layer refuses any update or delete against that revision or its lines.
# Any further change creates a brand-new revision (revision_number + 1)
# that starts from a copy of the locked lines. This gives a full,
# tamper-evident history instead of mutating figures in place.
# ---------------------------------------------------------------------------
class EngineerTakeoff(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "engineer_takeoffs"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    discipline: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    current_revision_number: Mapped[int] = mapped_column(Integer, default=1)

    revisions: Mapped[list["EngineerTakeoffRevision"]] = relationship(
        back_populates="takeoff", order_by="EngineerTakeoffRevision.revision_number"
    )


class EngineerTakeoffRevision(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "engineer_takeoff_revisions"

    takeoff_id: Mapped[str] = mapped_column(ForeignKey("engineer_takeoffs.id"), nullable=False, index=True)
    revision_number: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[TakeoffStatus] = mapped_column(
        Enum(TakeoffStatus, native_enum=False), default=TakeoffStatus.draft, nullable=False
    )
    notes: Mapped[str] = mapped_column(Text, default="")
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    locked_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)

    takeoff: Mapped["EngineerTakeoff"] = relationship(back_populates="revisions")
    lines: Mapped[list["EngineerTakeoffLine"]] = relationship(back_populates="revision")

    @property
    def is_locked(self) -> bool:
        return self.status in (TakeoffStatus.locked, TakeoffStatus.superseded)


class EngineerTakeoffLine(Base, UUIDPKMixin):
    __tablename__ = "engineer_takeoff_lines"

    revision_id: Mapped[str] = mapped_column(
        ForeignKey("engineer_takeoff_revisions.id"), nullable=False, index=True
    )
    item_code: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)

    revision: Mapped["EngineerTakeoffRevision"] = relationship(back_populates="lines")


# ---------------------------------------------------------------------------
# Independent AI Takeoff — deliberately NOT linked to the engineer takeoff
# at creation time. It is generated from the same project documents but by
# an automated pipeline, so it can be compared against the engineer's
# figures later (see verify.py) without either side having influenced the
# other.
# ---------------------------------------------------------------------------
class AITakeoffStatus(str, enum.Enum):
    generated = "generated"
    superseded = "superseded"


class AITakeoff(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "ai_takeoffs"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    discipline: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    model_version: Mapped[str] = mapped_column(String(100), default="")
    status: Mapped[AITakeoffStatus] = mapped_column(
        Enum(AITakeoffStatus, native_enum=False), default=AITakeoffStatus.generated
    )

    lines: Mapped[list["AITakeoffLine"]] = relationship(back_populates="ai_takeoff")


class AITakeoffLine(Base, UUIDPKMixin):
    __tablename__ = "ai_takeoff_lines"

    ai_takeoff_id: Mapped[str] = mapped_column(ForeignKey("ai_takeoffs.id"), nullable=False, index=True)
    item_code: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)
    confidence_score: Mapped[float] = mapped_column(Float, default=0.0)

    ai_takeoff: Mapped["AITakeoff"] = relationship(back_populates="lines")
