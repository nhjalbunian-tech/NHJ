import enum
from datetime import date

from sqlalchemy import Date, Enum, Float, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin


class DocStatus(str, enum.Enum):
    draft = "draft"
    submitted = "submitted"
    approved = "approved"
    rejected = "rejected"
    closed = "closed"


# --- Purchase Requisition ---------------------------------------------------
class PurchaseRequisition(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "purchase_requisitions"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    pr_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    requested_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[DocStatus] = mapped_column(Enum(DocStatus, native_enum=False), default=DocStatus.draft)

    lines: Mapped[list["PurchaseRequisitionLine"]] = relationship(back_populates="requisition")


class PurchaseRequisitionLine(Base, UUIDPKMixin):
    __tablename__ = "purchase_requisition_lines"

    pr_id: Mapped[str] = mapped_column(ForeignKey("purchase_requisitions.id"), nullable=False, index=True)
    item_code: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)
    estimated_unit_rate: Mapped[float] = mapped_column(Float, default=0.0)

    requisition: Mapped["PurchaseRequisition"] = relationship(back_populates="lines")


# --- Purchase Order ----------------------------------------------------------
class PurchaseOrder(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "purchase_orders"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    pr_id: Mapped[str | None] = mapped_column(ForeignKey("purchase_requisitions.id"), nullable=True)
    po_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    supplier_name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[DocStatus] = mapped_column(Enum(DocStatus, native_enum=False), default=DocStatus.draft)

    lines: Mapped[list["PurchaseOrderLine"]] = relationship(back_populates="order")


class PurchaseOrderLine(Base, UUIDPKMixin):
    __tablename__ = "purchase_order_lines"

    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.id"), nullable=False, index=True)
    item_code: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)
    unit_rate: Mapped[float] = mapped_column(Float, default=0.0)

    order: Mapped["PurchaseOrder"] = relationship(back_populates="lines")


# --- Goods Received Note -----------------------------------------------------
class GoodsReceivedNote(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "goods_received_notes"

    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.id"), nullable=False, index=True)
    grn_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    received_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    received_date: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[DocStatus] = mapped_column(Enum(DocStatus, native_enum=False), default=DocStatus.draft)

    lines: Mapped[list["GRNLine"]] = relationship(back_populates="grn")


class GRNLine(Base, UUIDPKMixin):
    __tablename__ = "grn_lines"

    grn_id: Mapped[str] = mapped_column(ForeignKey("goods_received_notes.id"), nullable=False, index=True)
    po_line_id: Mapped[str] = mapped_column(ForeignKey("purchase_order_lines.id"), nullable=False)
    quantity_received: Mapped[float] = mapped_column(Float, nullable=False)
    remarks: Mapped[str] = mapped_column(String(500), default="")

    grn: Mapped["GoodsReceivedNote"] = relationship(back_populates="lines")


# --- Material Issue -----------------------------------------------------------
class MaterialIssue(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "material_issues"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    issue_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    issued_to: Mapped[str] = mapped_column(String(255), nullable=False)
    issued_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    issue_date: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[DocStatus] = mapped_column(Enum(DocStatus, native_enum=False), default=DocStatus.draft)

    lines: Mapped[list["MaterialIssueLine"]] = relationship(back_populates="issue")


class MaterialIssueLine(Base, UUIDPKMixin):
    __tablename__ = "material_issue_lines"

    material_issue_id: Mapped[str] = mapped_column(
        ForeignKey("material_issues.id"), nullable=False, index=True
    )
    item_code: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)
    source_grn_line_id: Mapped[str | None] = mapped_column(ForeignKey("grn_lines.id"), nullable=True)

    issue: Mapped["MaterialIssue"] = relationship(back_populates="lines")
