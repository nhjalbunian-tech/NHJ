from sqlalchemy import Float, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, UUIDPKMixin

# Seeded on first run; category groups units that can be converted between
# one another (you can convert m -> ft, but never m -> kg).
DEFAULT_UNITS: list[dict] = [
    {"code": "mm", "name": "millimeter", "category": "length"},
    {"code": "cm", "name": "centimeter", "category": "length"},
    {"code": "m", "name": "meter", "category": "length"},
    {"code": "ft", "name": "foot", "category": "length"},
    {"code": "in", "name": "inch", "category": "length"},
    {"code": "m2", "name": "square meter", "category": "area"},
    {"code": "ft2", "name": "square foot", "category": "area"},
    {"code": "m3", "name": "cubic meter", "category": "volume"},
    {"code": "ft3", "name": "cubic foot", "category": "volume"},
    {"code": "kg", "name": "kilogram", "category": "weight"},
    {"code": "ton", "name": "metric ton", "category": "weight"},
    {"code": "lb", "name": "pound", "category": "weight"},
    {"code": "ea", "name": "each", "category": "count"},
    {"code": "lm", "name": "linear meter", "category": "length"},
]

# (from_code, to_code, factor) such that value_in_to = value_in_from * factor
DEFAULT_CONVERSIONS: list[tuple[str, str, float]] = [
    ("mm", "m", 0.001),
    ("cm", "m", 0.01),
    ("m", "ft", 3.28084),
    ("ft", "m", 0.3048),
    ("in", "m", 0.0254),
    ("m2", "ft2", 10.7639),
    ("ft2", "m2", 0.092903),
    ("m3", "ft3", 35.3147),
    ("ft3", "m3", 0.0283168),
    ("kg", "ton", 0.001),
    ("ton", "kg", 1000.0),
    ("kg", "lb", 2.20462),
    ("lb", "kg", 0.453592),
]


class UnitOfMeasure(Base, UUIDPKMixin):
    __tablename__ = "units_of_measure"

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    category: Mapped[str] = mapped_column(String(50), nullable=False)


class UnitConversion(Base, UUIDPKMixin):
    __tablename__ = "unit_conversions"

    from_unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)
    to_unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)
    factor: Mapped[float] = mapped_column(Float, nullable=False)
