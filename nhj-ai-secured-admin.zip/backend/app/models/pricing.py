from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Float, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin


class PriceList(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "price_lists"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    effective_date: Mapped[date] = mapped_column(Date, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    items: Mapped[list["PriceListItem"]] = relationship(back_populates="price_list")


class PriceListItem(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "price_list_items"

    price_list_id: Mapped[str] = mapped_column(ForeignKey("price_lists.id"), nullable=False, index=True)
    item_code: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    unit_id: Mapped[str] = mapped_column(ForeignKey("units_of_measure.id"), nullable=False)

    material_rate: Mapped[float] = mapped_column(Float, default=0.0)
    labor_rate: Mapped[float] = mapped_column(Float, default=0.0)
    equipment_rate: Mapped[float] = mapped_column(Float, default=0.0)

    price_list: Mapped["PriceList"] = relationship(back_populates="items")

    @property
    def total_rate(self) -> float:
        return self.material_rate + self.labor_rate + self.equipment_rate
