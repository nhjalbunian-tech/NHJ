import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin


class ApprovalStatus(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"
    cancelled = "cancelled"


class ApprovalRequest(Base, UUIDPKMixin, TimestampMixin):
    """
    Generic approval envelope for any entity in the platform. `entity_type`
    is a short string tag ("purchase_requisition", "purchase_order",
    "engineer_takeoff_revision", ...) and `entity_id` is that entity's UUID
    — a polymorphic reference kept deliberately loose in v0.1 so new
    approvable entity types don't require schema changes.
    """
    __tablename__ = "approval_requests"

    entity_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    entity_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    requested_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    current_step_order: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[ApprovalStatus] = mapped_column(
        Enum(ApprovalStatus, native_enum=False), default=ApprovalStatus.pending
    )

    steps: Mapped[list["ApprovalStep"]] = relationship(
        back_populates="request", order_by="ApprovalStep.step_order"
    )


class ApprovalStep(Base, UUIDPKMixin):
    __tablename__ = "approval_steps"

    request_id: Mapped[str] = mapped_column(ForeignKey("approval_requests.id"), nullable=False, index=True)
    step_order: Mapped[int] = mapped_column(Integer, nullable=False)
    approver_role_id: Mapped[str] = mapped_column(ForeignKey("roles.id"), nullable=False)
    status: Mapped[ApprovalStatus] = mapped_column(
        Enum(ApprovalStatus, native_enum=False), default=ApprovalStatus.pending
    )
    acted_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    acted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    comments: Mapped[str] = mapped_column(Text, default="")

    request: Mapped["ApprovalRequest"] = relationship(back_populates="steps")
