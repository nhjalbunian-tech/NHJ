import enum

from sqlalchemy import Boolean, Enum, Float, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin


class VerificationStatus(str, enum.Enum):
    pending = "pending"          # verifier has not yet submitted their figures
    submitted = "submitted"      # verifier submitted blind, variance now computed
    completed = "completed"      # reviewed/closed out


class VerificationSession(Base, UUIDPKMixin, TimestampMixin):
    """
    "Blind" means: the verifier records their own independent quantity per
    line via VerificationLine.verifier_qty while engineer_qty/ai_qty stay
    write-only from their perspective (the API does not return those two
    fields until the verifier has submitted a value for that line — see
    services/verify_service.py). Only after submission is the variance
    revealed, preventing anchoring on either source's numbers.
    """
    __tablename__ = "verification_sessions"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    engineer_revision_id: Mapped[str] = mapped_column(
        ForeignKey("engineer_takeoff_revisions.id"), nullable=False
    )
    ai_takeoff_id: Mapped[str] = mapped_column(ForeignKey("ai_takeoffs.id"), nullable=False)
    verifier_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[VerificationStatus] = mapped_column(
        Enum(VerificationStatus, native_enum=False), default=VerificationStatus.pending
    )

    lines: Mapped[list["VerificationLine"]] = relationship(back_populates="session")


class VerificationLine(Base, UUIDPKMixin):
    __tablename__ = "verification_lines"

    session_id: Mapped[str] = mapped_column(ForeignKey("verification_sessions.id"), nullable=False, index=True)
    item_code: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(String(500), nullable=False)

    engineer_qty: Mapped[float] = mapped_column(Float, nullable=False)
    ai_qty: Mapped[float] = mapped_column(Float, nullable=False)
    verifier_qty: Mapped[float | None] = mapped_column(Float, nullable=True)

    variance_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    flagged: Mapped[bool] = mapped_column(Boolean, default=False)

    session: Mapped["VerificationSession"] = relationship(back_populates="lines")
