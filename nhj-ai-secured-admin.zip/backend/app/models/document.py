import enum

from sqlalchemy import Enum, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin


class DocumentType(str, enum.Enum):
    drawing = "drawing"
    specification = "specification"
    boq = "boq"
    contract = "contract"
    other = "other"


class ProjectDocument(Base, UUIDPKMixin, TimestampMixin):
    """
    Metadata only — v0.1 does not store file bytes. `file_path` points at
    wherever the binary lives (local disk path or, later, object storage
    key/URL); `file_hash` lets callers detect duplicate/changed uploads.
    """
    __tablename__ = "project_documents"

    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    doc_type: Mapped[DocumentType] = mapped_column(Enum(DocumentType, native_enum=False), nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1)
    file_path: Mapped[str] = mapped_column(String(1024), default="")
    file_hash: Mapped[str] = mapped_column(String(128), default="")
    uploaded_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
