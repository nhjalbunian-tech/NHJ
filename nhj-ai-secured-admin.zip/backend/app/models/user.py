from sqlalchemy import JSON, Boolean, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base, TimestampMixin, UUIDPKMixin

# Default roles seeded on first run. `permissions` is a flat list of
# permission codes (e.g. "takeoff:lock", "po:approve"). Kept as a JSON
# column rather than a join table so v0.1 can evolve permission sets
# without a migration; a normalized Permission table can be introduced
# later without touching the User model.
DEFAULT_ROLES: list[dict] = [
    {
        "name": "admin",
        "description": "Full system access",
        "permissions": ["*"],
    },
    {
        "name": "project_manager",
        "description": "Manages projects, approves procurement and takeoffs",
        "permissions": [
            "project:create", "project:read", "project:update",
            "document:create", "document:read",
            "takeoff:read", "takeoff:lock",
            "verify:read",
            "pricing:read",
            "pr:approve", "po:approve",
            "approval:act",
        ],
    },
    {
        "name": "engineer",
        "description": "Creates and revises engineer takeoffs",
        "permissions": [
            "project:read", "document:read", "document:create",
            "takeoff:create", "takeoff:update", "takeoff:read", "takeoff:lock",
            "verify:read",
        ],
    },
    {
        "name": "ai_agent",
        "description": "System role used by the independent AI takeoff pipeline",
        "permissions": ["ai_takeoff:create", "ai_takeoff:read", "project:read", "document:read"],
    },
    {
        "name": "estimator",
        "description": "Owns pricing foundation",
        "permissions": ["pricing:create", "pricing:read", "pricing:update", "takeoff:read"],
    },
    {
        "name": "procurement",
        "description": "Raises PR/PO/GRN/material issues",
        "permissions": [
            "pr:create", "pr:read", "po:create", "po:read",
            "grn:create", "grn:read", "material_issue:create", "material_issue:read",
            "pricing:read",
        ],
    },
    {
        "name": "verifier",
        "description": "Performs blind verification between engineer and AI takeoffs",
        "permissions": ["verify:create", "verify:update", "verify:read", "takeoff:read", "ai_takeoff:read"],
    },
    {
        "name": "auditor",
        "description": "Read-only access to the audit log and all entities",
        "permissions": ["audit:read", "project:read", "takeoff:read", "verify:read", "pr:read", "po:read"],
    },
]


class Role(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    description: Mapped[str] = mapped_column(String(255), default="")
    permissions: Mapped[list] = mapped_column(JSON, default=list)

    users: Mapped[list["User"]] = relationship(back_populates="role")

    def has_permission(self, code: str) -> bool:
        return "*" in self.permissions or code in self.permissions


class User(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "users"

    username: Mapped[str | None] = mapped_column(String(100), unique=True, nullable=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    role_id: Mapped[str] = mapped_column(ForeignKey("roles.id"), nullable=False)
    role: Mapped["Role"] = relationship(back_populates="users")
