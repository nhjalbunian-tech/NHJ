from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, UUIDPKMixin


class AuditLog(Base, UUIDPKMixin):
    """
    Append-only by construction: no route or service function in this
    codebase issues an UPDATE or DELETE against this table — only
    audit_service.record() ever inserts. Keep it that way; if a future
    change needs to "correct" an entry, insert a new compensating record
    instead of mutating history.
    """
    __tablename__ = "audit_logs"

    entity_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    entity_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    action: Mapped[str] = mapped_column(String(50), nullable=False)  # create/update/lock/approve/reject/...
    actor_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False
    )
    before_state: Mapped[str] = mapped_column(Text, default="")  # JSON-encoded snapshot
    after_state: Mapped[str] = mapped_column(Text, default="")   # JSON-encoded snapshot
