"""
One-off utility: resets the existing admin user's password without
touching any other data (projects, documents, takeoffs, etc.).

Why this is needed: app/db/init_db.py only seeds the admin account when
the users table is completely empty. If an admin user already exists
from an earlier run with a password nobody remembers, the app never
resets it on subsequent startups — login then fails silently against
the documented default password.

Usage (from the backend/ directory, with your venv activated):
    python reset_admin_password.py "YourNewStrong#Password123!"

If no password is given, it resets to the documented default:
    NHJ@Admin#2026!Strong
"""
import sys

from app.core.security import hash_password, validate_password_strength
from app.db.session import SessionLocal
from app.models.user import User

DEFAULT_PASSWORD = "NHJ@Admin#2026!Strong"


def main() -> None:
    new_password = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PASSWORD

    error = validate_password_strength(new_password)
    if error:
        print(f"Password rejected: {error}")
        sys.exit(1)

    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.username == "admin").first()
        if admin is None:
            print("No user with username 'admin' found. Nothing to reset.")
            sys.exit(1)

        admin.hashed_password = hash_password(new_password)
        admin.must_change_password = True
        db.commit()
        print(f"Password reset for user '{admin.username}' ({admin.email}).")
        print(f"New password: {new_password}")
        print("must_change_password is set to True, so you'll be asked to change it after login.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
